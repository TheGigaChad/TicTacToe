# tic-tac-toe game
This is a simple version of a tic-tac-toe game where the player will play 
against an AI.

## Game Design
The game design is that of the traditional tic-tac-toe game, where each player takes turns
to try and create a horizontal, vertical or diagonal line of their token unobstructed by the other player
from one side to the other.

If this is not enough information, please refer to the following link to play.
* [Online Tic Tac Toe game](https://playtictactoe.org)


### Rules
* The Player always goes first (and defines his token).
* The AI goes second automatically.
* When either the player or AI wins, the game is finished and cannot be played anymore.However, 
   the game gameState is still viewable.

### Implementation
The game has been broken up into simple logical components.
#### The Game
Contains all information regarding current gameState of the game such as game gameState,
the board gameState, the player, the AI and the winner.
#### The Player
The Player object which contains the Token (X/O) that the player will use.
#### The AI
This is an extension of the player class that will have the ability to generate moves.

### Assumptions
The following assumptions have been made given the implementation:
1. The AI will try its best to win - that means it will ALWAYS block the user or
    win where a win condition is available.  This is toggleable (See FORCE_RANDOM_POSITION_PLACEMENT in AI class)
2. Game storage is local and in memory.
3. Run locally on 8080 port.