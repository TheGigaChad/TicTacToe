package com.java.master.tictactoe.service;

import com.java.master.tictactoe.exception.InvalidGameIdException;
import com.java.master.tictactoe.exception.InvalidGameStateException;
import com.java.master.tictactoe.exception.InvalidMoveException;
import com.java.master.tictactoe.model.Game;
import com.java.master.tictactoe.model.Move;
import com.java.master.tictactoe.model.GameState;
import com.java.master.tictactoe.model.Turn;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

;

class GameServiceTest {


    private GameService gameService;
    private AutoCloseable autoCloseable;


    @BeforeEach
    void setUp() {
        autoCloseable = MockitoAnnotations.openMocks(this);
        gameService = new GameService();
    }

    @AfterEach
    void tearDown() throws Exception {
        autoCloseable.close();
    }

    @Test
    void createGame() {
        Game game = gameService.createGame();
        assertEquals(game.getGameState(), GameState.OPEN);
    }

    @Test
    void connectToGame() throws InvalidGameIdException {
        Game game = gameService.createGame();
        game = gameService.connectToGame(game.getGameId());
        assertNotNull(game);
    }

    @Test
    void fulfillMove() throws InvalidGameStateException, InvalidGameIdException, InvalidMoveException {
        final int X = 1;
        final int Y = 2;

        Game game = gameService.createGame();
        Move firstMove = new Move(game.getPlayer().getPlayerToken(), X, Y);
        Turn firstTurn = game.getTurn();
        game = gameService.fulfillMove(firstMove, game.getGameId());

        // assert game state isn't finished, turn changed correctly and no winner assigned.
        assertEquals(game.getGameState(), GameState.OPEN);
        assertNotEquals(firstTurn, game.getTurn());
        assertNull(game.getWinner());

        // assert placement and value is correct.
        int[][] board = game.getBoard();
        assertEquals(board[X][Y], firstMove.getType().getValue());
    }

}