package com.java.master.tictactoe.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.java.master.tictactoe.model.Player;
import com.java.master.tictactoe.model.Position;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.nio.charset.StandardCharsets;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class GameControllerTest {
    private final String BASE_URL = "/tictactoe/game";
    private final String TOKEN_STRING = "O";
    public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), StandardCharsets.UTF_8);
    @Autowired
    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    private ObjectWriter objectWriter;
    private String requestJson;

    @BeforeEach
    void setUp() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        objectWriter = mapper.writer().withDefaultPrettyPrinter();
        requestJson = objectWriter.writeValueAsString(new Player(TOKEN_STRING));

    }

    @Test
    void start() throws Exception {
        this.mockMvc.perform(post(BASE_URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andDo(print()).andExpect(status().isOk());
    }

    @Test
    void connect() throws Exception {
        MvcResult result = this.mockMvc.perform(post(BASE_URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andReturn();
        String id = result.getResponse().getContentAsString();
        final String URL = BASE_URL + "/" + id;
        this.mockMvc.perform(get(URL)).andDo(print()).andExpect(status().isOk());
    }

    @Test
    void move() throws Exception {
        MvcResult result = this.mockMvc.perform(post(BASE_URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andReturn();
        String id = result.getResponse().getContentAsString();
        final String URL = BASE_URL + "/" + id + "/move";
        final int X = 1;
        final int Y = 2;
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter writer = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = writer.writeValueAsString(new Position(X, Y));
        this.mockMvc.perform(post(URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests that a duplicate move will return a bad method error (405)
     *
     * @throws Exception generic
     */
    @Test
    void duplicatePositionMove() throws Exception {
        MvcResult result = this.mockMvc.perform(post(BASE_URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andReturn();
        String id = result.getResponse().getContentAsString();
        final String URL = BASE_URL + "/" + id + "/move";
        final int X = 1;
        final int Y = 2;
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter writer = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = writer.writeValueAsString(new Position(X, Y));
        this.mockMvc.perform(post(URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andDo(print()).andExpect(status().isOk());
        this.mockMvc.perform(post(URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andDo(print()).andExpect(status().isMethodNotAllowed());
    }

    /**
     * Tests that a move outside of board bounds will return a bad method error (405)
     *
     * @throws Exception generic
     */
    @Test
    void outOfBoundsPositionMove() throws Exception {
        MvcResult result = this.mockMvc.perform(post(BASE_URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andReturn();
        String id = result.getResponse().getContentAsString();
        final String URL = BASE_URL + "/" + id + "/move";
        final int X = -1;
        final int Y = -1;
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter writer = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = writer.writeValueAsString(new Position(X, Y));
        this.mockMvc.perform(post(URL).contentType(APPLICATION_JSON_UTF8).content(requestJson)).andDo(print()).andExpect(status().isMethodNotAllowed());
    }
}