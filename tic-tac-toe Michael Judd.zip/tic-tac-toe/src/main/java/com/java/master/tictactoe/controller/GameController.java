package com.java.master.tictactoe.controller;

import com.java.master.tictactoe.exception.InvalidGameIdException;
import com.java.master.tictactoe.exception.InvalidGameStateException;
import com.java.master.tictactoe.exception.InvalidMoveException;
import com.java.master.tictactoe.model.*;
import com.java.master.tictactoe.service.GameService;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Arrays;
import java.util.logging.Logger;


@RestController
@RequestMapping("/tictactoe")
public class GameController {
    Logger logger = Logger.getLogger(this.getClass().getName());
    private final GameService gameService;

    public GameController() {
        this.gameService = new GameService();
    }

    @PostMapping("/game")
    public ResponseEntity<String> start(@RequestBody Player player) {
        Game game = gameService.createGame(player);
        logger.info("starting game: " + game.getGameId());
        return ResponseEntity.ok().body(game.getGameId());
    }

    @GetMapping("/game/{id}")
    public ResponseEntity<String> connect(@PathVariable String id) {
        try {
            logger.info("connecting to game: " + id);
            Game game = gameService.connectToGame(id);
            return ResponseEntity.ok(Arrays.deepToString(game.getBoard()));
        } catch (InvalidGameIdException e) {
            logger.warning(e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.METHOD_NOT_ALLOWED);
        }

    }


    @PostMapping("/game/{id}/move")
    public ResponseEntity<Game> move(@RequestBody Position position, @PathVariable String id) {
        try {
            // User move
            Game game = gameService.connectToGame(id);
            Move move = new Move(game.getPlayer().getPlayerToken(), position.getRow(), position.getCol());
            logger.info("Making a move: " + move);
            game = gameService.fulfillMove(move, id);

            if (game.getGameState() != GameState.OPEN) {
                logger.info("Game is finished: the winner is " + game.getWinner() + " (Game state : " + game.getGameState() + ")");
                return ResponseEntity.ok(game);
            }

            // AI move
            Move aiMove = game.generateMove();
            logger.info("Now generating AI move: " + aiMove);
            game = gameService.fulfillMove(aiMove, id);
            if (game.getGameState() != GameState.OPEN) {
                logger.info("Game is finished: the winner is " + game.getWinner() + " (Game state : " + game.getGameState() + ")");
            }
            return ResponseEntity.ok(game);

        } catch (InvalidMoveException e) {
            logger.warning(e.getMessage());
            return new ResponseEntity<>(HttpStatus.METHOD_NOT_ALLOWED);
        } catch (InvalidGameStateException e) {
            logger.warning(e.getMessage());
            return new ResponseEntity<>(HttpStatus.METHOD_NOT_ALLOWED);
        } catch (InvalidGameIdException e) {
            logger.warning(e.getMessage());
            return new ResponseEntity<>(HttpStatus.METHOD_NOT_ALLOWED);
        }

    }

    @Data
    @Accessors(chain = true)
    public static class ErrorDTO {
        private String error;
    }

    @ControllerAdvice
    public static class GenericExceptionHandlers extends ResponseEntityExceptionHandler {
        @Override
        protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
            logger.warn("Request: " + request + " was unable to be parsed. \n" + e.getMessage());
            return new ResponseEntity<>(new ErrorDTO().setError(e.getMessage()), HttpStatus.METHOD_NOT_ALLOWED);
        }
    }

}
