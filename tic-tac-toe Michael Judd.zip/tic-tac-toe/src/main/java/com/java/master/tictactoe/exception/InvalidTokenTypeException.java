package com.java.master.tictactoe.exception;

public class InvalidTokenTypeException extends Exception {

    private String message;

    public InvalidTokenTypeException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }
}
