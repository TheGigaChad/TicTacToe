package com.java.master.tictactoe.model;


/**
 * Data Class holding the information regarding the requested move (change to board)
 */
public class Move {
    private final Token type;
    private final int x;
    private final int y;

    public Move(Token token, int x, int y) {
        this.type = token;
        this.x = x;
        this.y = y;
    }

    public Token getType() {
        return type;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }


    public String toString(){
        return "[" + "Type: " + this.type + ", "
                   + "x: " + this.x + ", "
                   + "y: " + this.y + "]";
    }
}
