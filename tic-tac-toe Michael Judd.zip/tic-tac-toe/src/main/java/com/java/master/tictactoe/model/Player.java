package com.java.master.tictactoe.model;

import java.util.Random;

public class Player {

    protected final Token playerToken;

    /**
     * Generates a player with random X/O TicTacToe object.
     */
    public Player() {
        Random random = new Random();
        this.playerToken = random.nextBoolean() ? Token.O : Token.X;
    }

    public Player(Token playerToken) {
        this.playerToken = playerToken;
    }

    public Player(String tokenString) {
        this.playerToken = Token.X.toString().equals(tokenString) ? Token.X : Token.O;
    }

    public Token getPlayerToken() {
        return this.playerToken;
    }

    public String toString() {
        return this.playerToken.toString();
    }
}
