package com.java.master.tictactoe.model;

public enum Token {
    X(1),
    O(2);

    private final int value;

    private Token(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    /**
     * Return the inverse for the provided TicTacToe.  Used to make the second player type constructor cleaner.
     *
     * @param token the TicTacToe we want to find the opposite for.
     * @return opposite TicTacToe object.
     */
    public static Token inverseOf(Token token) {
        return token == Token.X ? Token.O : Token.X;
    }

    public String toString() {
        return this == Token.X ? "X" : "O";
    }
}
