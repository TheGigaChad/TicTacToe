package com.java.master.tictactoe.model;

import java.util.UUID;

public class Game {

    private final String gameId;
    private Player player;
    private AI ai;
    private GameState gameState;
    private Turn turn;
    private static final int BOARD_SIZE = 3;
    private int[][] board;

    private Player winner;

    public Game() {
        this.gameId = UUID.randomUUID().toString();
        this.player = new Player();
        this.ai = new AI(Token.inverseOf(player.playerToken));
        this.gameState = GameState.OPEN;
        this.turn = player.playerToken == Token.O ? Turn.O : Turn.X;
        this.board = new int[BOARD_SIZE][BOARD_SIZE];
    }

    public Game(Player player) {
        this.gameId = UUID.randomUUID().toString();
        this.player = player;
        this.ai = new AI(Token.inverseOf(player.playerToken));
        this.gameState = GameState.OPEN;
        this.turn = player.playerToken == Token.O ? Turn.O : Turn.X;
        this.board = new int[BOARD_SIZE][BOARD_SIZE];
    }


    public String getGameId() {
        return this.gameId;
    }

    public GameState getGameState() {
        return this.gameState;
    }

    public int[][] getBoard() {
        return this.board;
    }

    public Player getWinner() {
        return this.winner;
    }

    public void setBoard(int[][] board) {
        this.board = board;
    }

    /**
     * Updates the Turn type.  To be called after each move.
     */
    public void updateTurn() {
        this.turn = this.turn == Turn.X ? Turn.O : Turn.X;
    }

    /**
     * Used to return the AI move generate.
     *
     * @return new AI generated move.
     */
    public Move generateMove() {
        return this.ai.generateMove(this);
    }

    public void setState(GameState gameState) {
        this.gameState = gameState;
    }

    public void setWinner(Move move) {
        this.winner = player.playerToken == move.getType() ? player : ai;

        setState(move.getType() == Token.X ? GameState.PLAYER_X_WON : GameState.PLAYER_O_WON);
    }

    public Turn getTurn() {
        return this.turn;
    }

    public Player getPlayer() {
        return this.player;
    }

}


