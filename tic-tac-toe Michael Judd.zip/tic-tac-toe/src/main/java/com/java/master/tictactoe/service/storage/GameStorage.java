package com.java.master.tictactoe.service.storage;

import com.java.master.tictactoe.model.Game;

import java.util.HashMap;
import java.util.Map;

public class GameStorage {

    private static Map<String, Game> games;
    private static GameStorage instance;

    private GameStorage() {
        games = new HashMap<>();
    }

    public static synchronized GameStorage getInstance() {
        if (instance == null) {
            instance = new GameStorage();
        }
        return instance;
    }

    public Game getGame(String id) {
        return games.getOrDefault(id, null);
    }

    public void setGame(Game game) {
        games.put(game.getGameId(), game);
    }

}
