package com.java.master.tictactoe.exception;

public class InvalidGameIdException extends Exception {

    private String message;

    public InvalidGameIdException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }
}
