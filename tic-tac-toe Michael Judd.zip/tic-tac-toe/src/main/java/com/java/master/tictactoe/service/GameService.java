package com.java.master.tictactoe.service;

import com.java.master.tictactoe.exception.InvalidGameIdException;
import com.java.master.tictactoe.exception.InvalidGameStateException;
import com.java.master.tictactoe.exception.InvalidMoveException;
import com.java.master.tictactoe.model.*;
import com.java.master.tictactoe.service.storage.GameStorage;
import org.springframework.stereotype.Service;

@Service
public class GameService {

    /**
     * Creates a new game.
     *
     * @return new Game.
     */
    public Game createGame() {
        Game game = new Game();
        GameStorage.getInstance().setGame(game);
        return game;
    }

    /**
     * Creates a new game with a chosen tictactoe option.
     *
     * @return new Game.
     */
    public Game createGame(Player player) {
        Game game = new Game(player);
        GameStorage.getInstance().setGame(game);
        return game;
    }

    /**
     * Checks the storage for an existing Game.
     *
     * @param gameId The relevant ID of the game we wish to connect to
     * @return The Game that exists in storage
     * @throws InvalidGameIdException When Game ID doesn't match anything in storage.
     */
    public Game connectToGame(String gameId) throws InvalidGameIdException {
        Game game = GameStorage.getInstance().getGame(gameId);
        if (game == null) {
            throw new InvalidGameIdException("Game ID " + gameId + " doesn't exist!");
        }
        return game;
    }

    /**
     * When passed a Move, will check validity and update board accordingly.
     *
     * @param moveRequest The information holding the x,y position, the TicTacToe type and game ID
     * @return Modified Game state
     * @throws InvalidMoveException when move is out of bounds or attempting to play in occupied spot.
     */
    public Game fulfillMove(Move moveRequest, String id) throws InvalidMoveException, InvalidGameIdException, InvalidGameStateException {
        Game game = GameStorage.getInstance().getGame(id);

        // Check for invalid game ID
        if (game == null) {
            throw new InvalidGameIdException("Game ID " + id + " doesn't exist!");
        }

        // Check the current game isn't finished.
        if (game.getGameState() != GameState.OPEN) {
            throw new InvalidGameStateException("Game has already been completed and the winner was " + game.getWinner());
        }

        // check it's the requested users turn to move
        if (game.getTurn().getValue() != moveRequest.getType().getValue()) {
            throw new InvalidMoveException("It isn't the current users' turn to move. " + moveRequest);
        }

        int[][] board = game.getBoard();

        // Out of bounds check
        if (moveRequest.getX() < 0 || moveRequest.getX() >= board.length ||
                moveRequest.getY() < 0 || moveRequest.getY() >= board.length) {
            throw new InvalidMoveException("Requested move is out of bounds. " + moveRequest);
        }

        // Occupied position check
        if (board[moveRequest.getX()][moveRequest.getY()] != 0) {
            throw new InvalidMoveException("Requested move position is occupied. " + moveRequest);
        }

        // Update board, update turn and save state to storage
        board[moveRequest.getX()][moveRequest.getY()] = moveRequest.getType().getValue();
        game.setBoard(board);

        if (checkForWinner(board, moveRequest)) {
            game.setWinner(moveRequest);
        } else if (checkForStaleMate(board)) {
            game.setState(GameState.TIE);
        }

        game.updateTurn();
        GameStorage.getInstance().setGame(game);
        return game;
    }

    /**
     * Checks for a stalemate condition
     *
     * @param board The current board state
     * @return whether a stalemate exists.
     */
    private boolean checkForStaleMate(int[][] board) {
        int zeros = 0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] == 0) {
                    zeros++;
                }
            }
        }
        return zeros == 0;
    }

    /**
     * Checks whether the current play has won the game.
     *
     * @param board current board state.
     * @param move  Current move made.
     * @return whether the move won the game.
     */
    private boolean checkForWinner(int[][] board, Move move) {
        return checkVertical(board, move) || checkHorizontal(board, move) || checkDiagonal(board, move);
    }

    /**
     * Checks whether the current play has won the game in diagonal move
     *
     * @param board current board state.
     * @param move  Current move made.
     * @return whether the move won the game diagonally.
     */
    private boolean checkDiagonal(int[][] board, Move move) {
        int moveValue = move.getType().getValue();
        boolean leftToRight = true;
        for (int i = 0; i < board.length; i++) {
            if (board[i][i] != moveValue) {
                leftToRight = false;
                break;
            }
        }

        boolean rightToLeft = true;
        for (int i = board.length - 1; i >= 0; i--) {
            if (board[i][board.length - i - 1] != moveValue) {
                rightToLeft = false;
                break;
            }
        }

        return leftToRight || rightToLeft;
    }


    /**
     * Checks whether the current play has won the game in horizontal move
     *
     * @param board current board state.
     * @param move  Current move made.
     * @return whether the move won the game horizontally.
     */
    private boolean checkHorizontal(int[][] board, Move move) {
        int moveValue = move.getType().getValue();

        for (int[] row : board) {
            int count = 0;
            for (int val : row) {
                if (val == moveValue) {
                    count++;
                    if (count == board.length) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    /**
     * Checks whether the current play has won the game in vertically move
     *
     * @param board current board state.
     * @param move  Current move made.
     * @return whether the move won the game vertically.
     */
    private boolean checkVertical(int[][] board, Move move) {
        int moveValue = move.getType().getValue();
        for (int i = 0; i < board[0].length; i++) {
            int count = 0;
            for (int j = 0; j < board.length; j++) {
                if (board[j][i] == moveValue) {
                    count++;
                    if (count == board.length) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
