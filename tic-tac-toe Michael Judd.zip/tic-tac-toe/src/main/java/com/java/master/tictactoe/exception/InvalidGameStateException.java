package com.java.master.tictactoe.exception;

public class InvalidGameStateException extends Exception {

    private String message;

    public InvalidGameStateException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }
}
