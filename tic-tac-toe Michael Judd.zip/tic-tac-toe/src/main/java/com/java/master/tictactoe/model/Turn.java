package com.java.master.tictactoe.model;

/**
 * Enum containing the current turn for the game.
 */
public enum Turn {
    X(1),
    O(2);

    private int value;

    private Turn(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
