package com.java.master.tictactoe.model;

/**
 * Enum containing the game state
 */
public enum GameState {
    OPEN,
    TIE,
    PLAYER_X_WON,
    PLAYER_O_WON
}
