package com.java.master.tictactoe.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * AI Class that has additional methods (Generate a move).
 */
public class AI extends Player {
    public AI(Token token) {
        super(token);
    }

    /**
     * The AI will assess the board based on current positions with a priority strategy of first checking to WIN
     * then checking to BLOCK the player then check to fill randomly.
     *
     * @param game The relevant game for which we will generate a move for.
     * @return a new Move to be fulfilled.
     */
    public Move generateMove(Game game) {
        int x = -1;
        int y = -1;
        int[][] board = game.getBoard();
        final boolean FORCE_RANDOM_POSITION_PLACEMENT = false;
        // Can we win in this move?
        Token token = this.playerToken;
        Position winPosition = canWin(board, token, x, y);
        if (!FORCE_RANDOM_POSITION_PLACEMENT && winPosition != null) {
            return new Move(token, winPosition.getCol(), winPosition.getRow());
        }

        // Can we block other player from winning?
        Token playerToken = game.getPlayer().getPlayerToken();
        Position blockPosition = canWin(board, playerToken, x, y);
        if (!FORCE_RANDOM_POSITION_PLACEMENT && blockPosition != null) {
            return new Move(token, blockPosition.getCol(), blockPosition.getCol());
        }

        // else, return random move
        return randomMove(board);
    }

    /**
     * Determines if a win condition is possible and will update the x,y position of this move.
     *
     * @param board current board state
     * @param token token to check for
     * @param x     x position
     * @param y     y position
     * @return whether a win is possible
     */
    private Position canWin(int[][] board, Token token, int x, int y) {
        Position horizontalPos = canWinHorizontal(board, token, x, y);
        if(horizontalPos != null){
            return horizontalPos;
        }
        Position verticalPos = canWinVertical(board, token, x, y);
        if(verticalPos != null){
            return verticalPos;
        }
        Position diagonalPos = canWinDiagonal(board, token, x, y);
        if(diagonalPos != null){
            return diagonalPos;
        }
        return null;
    }

    /**
     * Checks for a win in horizontal direction.
     *
     * @param board current board state
     * @param token token to check for
     * @param x     x position
     * @param y     y position
     * @return whether a win is possible in horizontal move
     */
    private Position canWinHorizontal(int[][] board, Token token, int x, int y) {

        for (int i = 0; i < board.length; i++) {
            // for every row, check for ONE zero and SIZE-1 of target
            int zeroCount = 0;
            int count = 0;
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] == 0) {
                    x = i;
                    y = j;
                    zeroCount++;
                } else if (board[i][j] == token.getValue()) {
                    count++;
                }
            }
            if (zeroCount == 1 && count == board.length - 1) {
                return new Position(x,y);
            }
        }

        return null;
    }

    /**
     * Checks for a win in vertical direction.
     *
     * @param board current board state
     * @param token token to check for
     * @param x     x position
     * @param y     y position
     * @return whether a win is possible in vertical move
     */
    private Position canWinVertical(int[][] board, Token token, int x, int y) {

        for (int i = 0; i < board[0].length; i++) {
            int zeroCount = 0;
            int count = 0;
            for (int j = 0; j < board.length; j++) {

                if (board[j][i] == token.getValue()) {
                    count++;
                } else if (board[j][i] == 0) {
                    zeroCount++;
                    x = j;
                    y = i;
                }
            }
            if (zeroCount == 1 && count == board.length - 1) {
                return new Position(x,y);
            }
        }
        return null;
    }

    /**
     * Checks for a win in diagonal direction.
     *
     * @param board current board state
     * @param token token to check for
     * @param x     x position
     * @param y     y position
     * @return whether a win is possible in diagonal move
     */
    private Position canWinDiagonal(int[][] board, Token token, int x, int y) {

        // Check left to right
        int count = 0;
        int zeroCount = 0;
        for (int i = 0; i < board.length; i++) {
            if (board[i][i] == token.getValue()) {
                count++;
            } else if (board[i][i] == 0) {
                zeroCount++;
                x = i;
                y = i;
            }
        }
        if (zeroCount == 1 && count == board.length - 1) {
            return new Position(y,x);
        }

        // Check right to left
        zeroCount = 0;
        count = 0;
        for (int i = board.length - 1; i >= 0; i--) {
            if (board[i][board.length - i - 1] == token.getValue()) {
                count++;
            } else if (board[i][board.length - i - 1] == 0) {
                zeroCount++;
                x = i;
                y = i;
            }
        }
        if(zeroCount == 1 && count == board.length - 1){
            return new Position(y,x);
        }
        return null;
    }

    /**
     * Random move generator
     *
     * @param board current board state
     * @return new random move.
     */
    private Move randomMove(int[][] board) {
        List<int[]> availableSpots = findAvailableSpots(board);
        Random random = new Random();
        int[] spot = availableSpots.get(random.nextInt(availableSpots.size()));
        return new Move(this.playerToken, spot[1], spot[0]);
    }


    /**
     * Returns a list of available positions within the board.
     *
     * @param board The current board state
     * @return List of available indexes.
     */
    private List<int[]> findAvailableSpots(int[][] board) {
        List<int[]> results = new ArrayList<>();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] == 0) {
                    results.add(new int[]{i, j});
                }
            }
        }
        return results;
    }

}
